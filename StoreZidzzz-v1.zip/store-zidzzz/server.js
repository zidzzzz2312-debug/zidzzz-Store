require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const SESSION_SECRET = process.env.SESSION_SECRET || "";

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]");
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(ROOT, "public")));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));

const products = [
  { id:"ml", game:"Mobile Legends", category:"MOBA", emoji:"⚔️", items:[
    ["86 Diamonds",19000],["172 Diamonds",38000],["257 Diamonds",57000],["344 Diamonds",76000],["568 Diamonds",119000]
  ]},
  { id:"ff", game:"Free Fire", category:"Battle Royale", emoji:"🔥", items:[
    ["70 Diamonds",10000],["140 Diamonds",20000],["355 Diamonds",49000],["720 Diamonds",97000],["1450 Diamonds",193000]
  ]},
  { id:"pubg", game:"PUBG Mobile", category:"Battle Royale", emoji:"🎯", items:[
    ["60 UC",16000],["325 UC",79000],["660 UC",159000],["1800 UC",399000]
  ]},
  { id:"roblox", game:"Roblox", category:"Gaming", emoji:"🧱", items:[
    ["80 Robux",18000],["160 Robux",36000],["400 Robux",85000],["800 Robux",169000]
  ]},
  { id:"voucher", game:"Voucher Digital", category:"Voucher", emoji:"🎟️", items:[
    ["Google Play Rp20.000",22000],["Google Play Rp50.000",53000],["Steam Wallet Rp45.000",48000]
  ]},
  { id:"other", game:"Produk Lainnya", category:"Digital", emoji:"✨", items:[
    ["Hubungi admin untuk produk lain",0]
  ]}
];

function readOrders() {
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")); } catch { return []; }
}
function writeOrders(orders) {
  const temp = ORDERS_FILE + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(orders, null, 2));
  fs.renameSync(temp, ORDERS_FILE);
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function adminAuth(req, res, next) {
  const token = req.headers["x-admin-token"];
  if (!token || !SESSION_SECRET) return res.status(401).json({ error:"Unauthorized" });
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(ADMIN_USER + ":" + ADMIN_PASSWORD).digest("hex");
  if (!safeEqual(token, expected)) return res.status(401).json({ error:"Unauthorized" });
  next();
}
app.get("/api/config", (req,res) => res.json({
  storeName: process.env.STORE_NAME || "Store Zidzzz",
  qrisImageUrl: process.env.QRIS_IMAGE_URL || "",
  danaNumber: process.env.DANA_NUMBER || "",
  danaAccountName: process.env.DANA_ACCOUNT_NAME || ""
}));
app.get("/api/products", (req,res) => res.json(products));
app.post("/api/orders", (req,res) => {
  const { gameId, itemName, userId, serverId, contact, paymentMethod } = req.body || {};
  const game = products.find(p => p.id === gameId);
  const item = game && game.items.find(i => i[0] === itemName);
  if (!game || !item || !userId || !contact || !["QRIS","DANA"].includes(paymentMethod)) {
    return res.status(400).json({ error:"Data pesanan belum lengkap atau tidak valid." });
  }
  if (String(userId).length > 80 || String(contact).length > 100 || String(serverId || "").length > 40) {
    return res.status(400).json({ error:"Data terlalu panjang." });
  }
  const order = {
    id: "ZZ" + Date.now().toString(36).toUpperCase() + crypto.randomBytes(2).toString("hex").toUpperCase(),
    game: game.game, gameId, itemName, amount: item[1],
    userId: String(userId).trim(), serverId: String(serverId || "").trim(),
    contact: String(contact).trim(), paymentMethod, status:"Menunggu Pembayaran",
    createdAt: new Date().toISOString()
  };
  const orders = readOrders(); orders.unshift(order); writeOrders(orders);
  res.status(201).json({ order });
});
app.post("/api/admin/login", (req,res) => {
  const { username, password } = req.body || {};
  if (!ADMIN_PASSWORD || !SESSION_SECRET) return res.status(503).json({ error:"Atur ADMIN_PASSWORD dan SESSION_SECRET di .env terlebih dahulu." });
  if (!safeEqual(username, ADMIN_USER) || !safeEqual(password, ADMIN_PASSWORD)) return res.status(401).json({ error:"Username atau password salah." });
  const token = crypto.createHmac("sha256", SESSION_SECRET).update(ADMIN_USER + ":" + ADMIN_PASSWORD).digest("hex");
  res.json({ token });
});
app.get("/api/admin/orders", adminAuth, (req,res) => res.json(readOrders()));
app.patch("/api/admin/orders/:id", adminAuth, (req,res) => {
  const allowed = ["Menunggu Pembayaran","Diproses","Selesai","Dibatalkan"];
  const { status } = req.body || {};
  if (!allowed.includes(status)) return res.status(400).json({ error:"Status tidak valid." });
  const orders = readOrders(); const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error:"Pesanan tidak ditemukan." });
  order.status = status; order.updatedAt = new Date().toISOString(); writeOrders(orders);
  res.json({ order });
});
app.get("*", (req,res) => res.sendFile(path.join(ROOT, "public", "index.html")));
app.listen(PORT, () => console.log(`Store Zidzzz running on http://localhost:${PORT}`));
