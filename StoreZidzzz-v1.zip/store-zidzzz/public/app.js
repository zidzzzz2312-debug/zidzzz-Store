const grid = document.getElementById("product-grid");
const modal = document.getElementById("order-modal");
const form = document.getElementById("order-form");
const result = document.getElementById("order-result");
let config = {};
document.getElementById("year").textContent = new Date().getFullYear();

async function loadStore(){
  try{
    const [p,c] = await Promise.all([fetch("/api/products"),fetch("/api/config")]);
    const products = await p.json(); config = await c.json();
    document.title = `${config.storeName} | Top-up Game`;
    document.querySelectorAll(".brand b").forEach(x=>x.textContent=config.storeName.toUpperCase());
    grid.innerHTML = products.map(game=>`
      <article class="product-card">
        <div class="product-icon">${game.emoji}</div><h3>${escapeHtml(game.game)}</h3>
        <p>${escapeHtml(game.category)} · Pilih nominal</p>
        <div class="items">${game.items.map(item=>`<button class="item-btn" ${item[1]===0?'disabled':''} data-game="${game.id}" data-item="${encodeURIComponent(item[0])}">${escapeHtml(item[0])}${item[1] ? ` · ${money(item[1])}` : ''}</button>`).join("")}</div>
      </article>`).join("");
    grid.querySelectorAll(".item-btn:not(:disabled)").forEach(btn=>btn.addEventListener("click",()=>openOrder(btn.dataset.game,decodeURIComponent(btn.dataset.item))));
  }catch(e){grid.innerHTML='<p class="notice">Produk belum dapat dimuat. Coba muat ulang halaman.</p>';}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function money(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);}
function openOrder(game,item){
  document.getElementById("game-id").value=game;document.getElementById("item-name").value=item;
  document.getElementById("selected-item").value=item;document.getElementById("modal-title").textContent="Pesan "+item;
  form.hidden=false;result.hidden=true;form.reset();document.getElementById("game-id").value=game;document.getElementById("item-name").value=item;document.getElementById("selected-item").value=item;
  modal.hidden=false;document.body.style.overflow="hidden";
}
function closeModal(){modal.hidden=true;document.body.style.overflow="";}
document.getElementById("close-modal").addEventListener("click",closeModal);
modal.addEventListener("click",e=>{if(e.target===modal)closeModal();});
form.addEventListener("submit",async e=>{
  e.preventDefault();
  const button=form.querySelector("button[type=submit]");button.disabled=true;button.textContent="Membuat pesanan…";
  const payload={gameId:document.getElementById("game-id").value,itemName:document.getElementById("item-name").value,userId:document.getElementById("user-id").value,serverId:document.getElementById("server-id").value,contact:document.getElementById("contact").value,paymentMethod:document.getElementById("payment").value};
  try{
    const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const data=await r.json();if(!r.ok)throw new Error(data.error||"Gagal membuat pesanan.");
    const o=data.order;
    form.hidden=true;result.hidden=false;
    const pay=o.paymentMethod==="DANA" ? `Transfer DANA ke <strong>${escapeHtml(config.danaNumber||"Nomor DANA belum diatur admin")}</strong> atas nama <strong>${escapeHtml(config.danaAccountName||"-")}</strong>.` : (config.qrisImageUrl ? `Scan QRIS: <br><img src="${escapeHtml(config.qrisImageUrl)}" alt="QRIS" style="max-width:220px;width:100%;margin-top:10px;border-radius:10px">` : "QRIS belum diatur admin. Hubungi admin untuk instruksi pembayaran.");
    result.innerHTML=`<div class="result-box"><strong>Pesanan berhasil dibuat!</strong><br>Nomor pesanan: <strong>${escapeHtml(o.id)}</strong><br>Produk: ${escapeHtml(o.game)} - ${escapeHtml(o.itemName)}<br>Total: <strong>${o.amount?money(o.amount):"Konfirmasi admin"}</strong><br>Status: Menunggu Pembayaran<hr style="border-color:#393256">${pay}<p>Setelah membayar, hubungi admin dan sertakan nomor pesanan. Jangan membagikan password akun game.</p><button class="primary-btn full" id="copy-order">Salin nomor pesanan</button></div>`;
    document.getElementById("copy-order").addEventListener("click",async()=>{await navigator.clipboard.writeText(o.id);document.getElementById("copy-order").textContent="Tersalin ✓";});
  }catch(err){alert(err.message);}finally{button.disabled=false;button.textContent="Buat Pesanan →";}
});
loadStore();
