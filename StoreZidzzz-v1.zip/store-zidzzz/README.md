# Store Zidzzz

Website top-up game berbasis HTML/CSS/JavaScript + Node.js (Express).

## Fitur
- Katalog Mobile Legends, Free Fire, PUBG Mobile, Roblox, voucher digital, dan produk lain.
- Form pemesanan dan nomor pesanan.
- Pilihan pembayaran QRIS atau DANA dengan instruksi pembayaran manual.
- Dashboard admin untuk melihat pesanan dan mengubah status.
- Layout responsif untuk HP.

## Menjalankan di komputer/hosting Node.js
1. Install Node.js 18 atau lebih baru.
2. Ekstrak project.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `ADMIN_PASSWORD` dan `SESSION_SECRET` dengan nilai acak yang panjang. Isi data QRIS/DANA jika sudah tersedia.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

## Deploy
Upload seluruh folder project ke hosting yang mendukung aplikasi Node.js. Jalankan `npm install`, lalu `npm start`. Atur environment variables dari dashboard hosting. Gunakan HTTPS. Pastikan folder `data/` dapat ditulis dan persistent agar pesanan tidak hilang saat restart/redeploy.

## Pengaturan pembayaran
Pembayaran pada starter project ini adalah **manual**:
- `QRIS_IMAGE_URL`: URL gambar QRIS milik toko yang sah.
- `DANA_NUMBER`: nomor DANA toko.
- `DANA_ACCOUNT_NAME`: nama akun penerima.

Jangan mengisi QRIS atau nomor milik orang lain tanpa izin. Admin harus memeriksa pembayaran melalui aplikasi/penyedia pembayaran sebelum mengubah status pesanan menjadi `Diproses` atau `Selesai`.

Untuk pembayaran otomatis, integrasikan payment gateway resmi di backend (server-side) dan verifikasi webhook/signature dari provider. Jangan pernah menyimpan secret key di `public/` atau browser.

## Keamanan & batasan starter
- Ganti kredensial admin dan session secret sebelum deploy.
- Simpan `.env` di server saja, jangan commit atau bagikan.
- Gunakan HTTPS dan backup `data/orders.json`.
- Starter ini menyimpan pesanan dalam file JSON; untuk toko ramai, gunakan database persisten.
- Harga produk hanyalah contoh awal. Perbarui berdasarkan harga supplier dan biaya resmi sebelum toko dibuka.
- Belum terhubung ke supplier/top-up API. Pesanan perlu diproses manual oleh admin sampai integrasi supplier resmi ditambahkan.
- Jangan meminta password akun game pelanggan. User ID/Player ID saja sesuai kebutuhan game.
- Email admin di halaman bantuan masih `admin@example.com`; ubah di `public/index.html`.
